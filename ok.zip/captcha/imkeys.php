<?php
	$oNameList = array("uzd","5pg","tpd","ju2","z47","car","slt","e2l","sx7","xd8");
	$oCharList = array("6","X","J","G","3","G","E","X","T","V");
// End of file imkeys.php