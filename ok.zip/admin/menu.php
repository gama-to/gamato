<a href="blog.php">Blog</a>
<a href="guestbook.php">Guestbook</a>
<a href="website_test.php">WebSite Test</a>
<a href="seo.php">SEO</a>
<span>
	<a href="login.php?logout">Logout</a>
</span>