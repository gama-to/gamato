<?php

// Users data
$imSettings['access']['users'] = array(
	'admin' => array(
		'id' => '4b10d6f0',
		'name' => 'Admin',
		'password' => '1v27n4we',
		'page' => 'index.html'
	),
	'newuser' => array(
		'id' => '822o639m',
		'name' => 'NewUser',
		'password' => '468y1u91',
		'page' => 'index.html'
	)
);

// Admins list
$imSettings['access']['admins'] = array('4b10d6f0');

// Page/Users permissions
$imSettings['access']['pages'] = array(
);

// End of file access.inc.php